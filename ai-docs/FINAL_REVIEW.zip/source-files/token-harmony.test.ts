/**
 * Goal 3 Cross-Library Quality: Design Token Consistency, Cascading, Contrast,
 * Specificity Harmony & RTL Directionality Automated Test Suite
 *
 * Mandate:
 * 1. Cross-Library CSS Collision & Specificity Audit (NUICSS superclasses in mixed DOM trees)
 * 2. Token Cascading & Contrast Verification (Light, Dark, High Contrast, WCAG AA)
 * 3. RTL / Directionality Visual Behavior (dir="rtl", logical properties, icons)
 * 4. Zero duplicate CSS definitions and cascade layers verification
 */

import { describe, it, expect, beforeEach } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

/* ==========================================================================
   COLOR MATHEMATICS & WCAG 2.2 AA CONTRAST UTILITIES
   ========================================================================== */

export function hexToRgb(hex: string): [number, number, number] {
  const clean = hex.replace('#', '').trim();
  if (clean.length === 3) {
    return [
      parseInt(clean[0] + clean[0], 16),
      parseInt(clean[1] + clean[1], 16),
      parseInt(clean[2] + clean[2], 16),
    ];
  }
  return [
    parseInt(clean.slice(0, 2), 16) || 0,
    parseInt(clean.slice(2, 4), 16) || 0,
    parseInt(clean.slice(4, 6), 16) || 0,
  ];
}

export function getRelativeLuminance(r: number, g: number, b: number): number {
  const [rs, gs, bs] = [r, g, b].map((val) => {
    const s = val / 255;
    return s <= 0.04045 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * rs + 0.7152 * gs + 0.0722 * bs;
}

export function calculateWcagContrast(hex1: string, hex2: string): number {
  const [r1, g1, b1] = hexToRgb(hex1);
  const [r2, g2, b2] = hexToRgb(hex2);
  const l1 = getRelativeLuminance(r1, g1, b1);
  const l2 = getRelativeLuminance(r2, g2, b2);
  const lighter = Math.max(l1, l2);
  const darker = Math.min(l1, l2);
  return (lighter + 0.05) / (darker + 0.05);
}

/* ==========================================================================
   PATHS & SOURCES
   ========================================================================== */

const NUICSS_DIST_DIR = 'd:/stack/packages/nuicss/dist';
const NUICSS_SRC_DIR = 'd:/stack/packages/nuicss/src';

const STYLES_CSS_PATH = path.join(NUICSS_DIST_DIR, 'styles.css');
const THEME_CSS_PATH = path.join(NUICSS_SRC_DIR, 'styles/theme.css');

describe('Token Harmony, Cascading & Visual Integration (Goal 3)', () => {
  let stylesCss: string;
  let themeCss: string;

  beforeEach(() => {
    stylesCss = fs.readFileSync(STYLES_CSS_PATH, 'utf-8');
    themeCss = fs.readFileSync(THEME_CSS_PATH, 'utf-8');
  });

  /* ==========================================================================
     1. CROSS-LIBRARY CSS COLLISION & SPECIFICITY AUDIT
     ========================================================================== */

  describe('1. Cross-Library CSS Collision & Specificity Audit', () => {
    const REQUIRED_SUPERCLASSES = [
      'btn',
      'card',
      'input',
      'badge',
      'modal',
      'drawer',
      'datagrid',
      'kanban-board',
      'markon-editor',
      'chart-container',
    ];

    it('contains all 10 required semantic superclasses in NUICSS styles bundle', () => {
      for (const superclass of REQUIRED_SUPERCLASSES) {
        const dotPattern = new RegExp(`\\.${superclass}\\b`);
        expect(
          dotPattern.test(stylesCss),
          `Missing semantic superclass .${superclass} in compiled styles.css`
        ).toBe(true);
      }
    });

    it('enforces modern CSS Cascade Layers (@layer base,components,utilities) to prevent global style bleeding', () => {
      // Must declare @layer base,components,utilities; at the top
      expect(stylesCss).toMatch(/@layer\s+base,\s*components,\s*utilities;/);
    });

    it('contains zero un-scoped global element resets outside @layer base', () => {
      // In CSS Cascade Layers, base element resets like `button`, `table`, `input`
      // must reside within @layer base so author component classes in @layer components
      // or unlayered author styles always take precedence.
      const resetCssPath = path.join(NUICSS_SRC_DIR, 'styles/reset.css');
      const resetCss = fs.readFileSync(resetCssPath, 'utf-8');

      // reset.css must be wrapped in @layer base
      expect(resetCss).toMatch(/@layer\s+base\s*\{/);
    });

    it('uses :where() for zero-specificity token assignment (:where(:root))', () => {
      // Token declarations in theme.css use :where(:root) so tokens can be cleanly overridden
      // by consumers at (0,0,0) specificity
      expect(themeCss).toContain(':where(:root)');
      expect(themeCss).toContain(':where([data-theme=\'dark\'], .dark)');
    });

    it('provides dual-namespace parity for NUI and NUIX interoperability (.nui-* and .* superclasses)', () => {
      // NUICSS must provide matching .nui-* prefixed and un-prefixed superclasses
      // so React (NUI), native HTML (NUIX), and Vanilla co-exist cleanly
      const dualMapped = [
        'btn',
        'card',
        'input',
        'badge',
        'modal',
        'drawer',
        'accordion',
        'alert',
        'avatar',
      ];

      for (const cls of dualMapped) {
        expect(stylesCss).toContain(`.${cls}`);
        expect(stylesCss).toContain(`.nui-${cls}`);
      }
    });

    it('renders mixed library component superclasses in the same DOM tree without class clashes', () => {
      // Simulate a realistic DOM container embedding:
      // React NUI: .btn, .card, .badge, .modal
      // Native NUIX: .nui-btn, .nui-card, .datagrid, .drawer
      // Vanilla: .kanban-board, .chart-container, .markon-editor
      const mixedContainer = document.createElement('div');
      mixedContainer.className = 'workspace-root bg-page text-default p-4';
      mixedContainer.innerHTML = `
        <div class="card nui-card">
          <div class="card-header">
            <h3 class="card-title">Cross-Library Compound Container</h3>
            <span class="badge badge-primary">React NUI</span>
            <span class="badge nui-badge badge-success">NUIX HTML</span>
          </div>
          <div class="card-body flex gap-4">
            <button class="btn btn-primary">NUI Action</button>
            <button class="nui-btn nui-btn-outline">NUIX Action</button>
            <input class="input" placeholder="Type here..." />
          </div>
          <div class="datagrid-container">
            <table class="datagrid table">
              <thead><tr><th>Column</th></tr></thead>
              <tbody><tr><td>Data</td></tr></tbody>
            </table>
          </div>
          <div class="kanban-board flex gap-4">
            <div class="kanban-column">Column</div>
          </div>
          <div class="chart-container nui-chart-container relative">
            <svg class="chart-svg"></svg>
          </div>
          <div class="editor markon-editor relative">
            <div class="markon-render">Markdown Content</div>
          </div>
          <div class="modal hidden" role="dialog">
            <div class="modal-backdrop"></div>
            <div class="modal-content">Modal Body</div>
          </div>
          <div class="drawer hidden" role="dialog">
            <div class="drawer-content">Drawer Body</div>
          </div>
        </div>
      `;
      document.body.appendChild(mixedContainer);

      // Verify all elements query successfully
      expect(mixedContainer.querySelector('.card.nui-card')).not.toBeNull();
      expect(mixedContainer.querySelector('.btn.btn-primary')).not.toBeNull();
      expect(mixedContainer.querySelector('.nui-btn.nui-btn-outline')).not.toBeNull();
      expect(mixedContainer.querySelector('.input')).not.toBeNull();
      expect(mixedContainer.querySelector('.datagrid.table')).not.toBeNull();
      expect(mixedContainer.querySelector('.kanban-board')).not.toBeNull();
      expect(mixedContainer.querySelector('.chart-container.nui-chart-container')).not.toBeNull();
      expect(mixedContainer.querySelector('.markon-editor')).not.toBeNull();
      expect(mixedContainer.querySelector('.modal')).not.toBeNull();
      expect(mixedContainer.querySelector('.drawer')).not.toBeNull();

      document.body.removeChild(mixedContainer);
    });
  });

  /* ==========================================================================
     2. DESIGN TOKEN CASCADING & CONTRAST VERIFICATION
     ========================================================================== */

  describe('2. Design Token Cascading & Contrast Verification', () => {
    const ESSENTIAL_TOKENS = [
      '--bg-surface',
      '--bg-page',
      '--fg-default',
      '--border-subtle',
      '--border-default',
      '--color-primary',
      '--focus-ring',
    ];

    it('defines all foundational tokens in :where(:root) light mode', () => {
      for (const token of ESSENTIAL_TOKENS) {
        expect(
          themeCss,
          `Theme CSS missing essential token definition: ${token}`
        ).toContain(`${token}:`);
      }
    });

    it('cascades all foundational tokens under dark mode (:where([data-theme="dark"], .dark))', () => {
      const darkModeBlockRegex = /:where\(\[data-theme=['"]dark['"]\],\s*\.dark\)\s*\{([^}]+)\}/g;
      let match;
      let combinedDarkModeDeclarations = '';

      while ((match = darkModeBlockRegex.exec(themeCss)) !== null) {
        combinedDarkModeDeclarations += match[1];
      }

      expect(combinedDarkModeDeclarations.length).toBeGreaterThan(0);

      const darkOverriddenTokens = [
        '--bg-page',
        '--bg-surface',
        '--border-default',
        '--border-subtle',
        '--color-primary-hover',
      ];

      for (const token of darkOverriddenTokens) {
        expect(
          combinedDarkModeDeclarations,
          `Dark mode block missing token cascade: ${token}`
        ).toContain(`${token}:`);
      }
    });

    it('provides high contrast token overrides under @media (prefers-contrast: more)', () => {
      expect(themeCss).toContain('@media (prefers-contrast: more)');
      expect(themeCss).toMatch(/--focus-ring:\s*#000000;/);
      expect(themeCss).toMatch(/--focus-ring:\s*#ffffff;/);
    });

    it('verifies WCAG 2.2 AA contrast in Light Mode (min 4.5:1 text, 3:1 non-text/borders)', () => {
      // Light Mode Tokens:
      // --bg-surface: #ffffff
      // --bg-page: #f8fafc (Slate 50)
      // --fg-default: #0f172a (Slate 900)
      // --color-primary: #2563eb (Brand 600)
      // --focus-ring: #0f172a

      const textOnSurface = calculateWcagContrast('#0f172a', '#ffffff');
      const textOnPage = calculateWcagContrast('#0f172a', '#f8fafc');
      const primaryOnSurface = calculateWcagContrast('#2563eb', '#ffffff');
      const primaryButtonFg = calculateWcagContrast('#ffffff', '#2563eb');
      const focusRingOnSurface = calculateWcagContrast('#0f172a', '#ffffff');

      // Normal text requires >= 4.5:1 (WCAG AA)
      expect(textOnSurface).toBeGreaterThanOrEqual(4.5);
      expect(textOnPage).toBeGreaterThanOrEqual(4.5);

      // Primary button text requires >= 4.5:1
      expect(primaryButtonFg).toBeGreaterThanOrEqual(4.5);

      // Non-text graphical UI and focus rings require >= 3.0:1
      expect(primaryOnSurface).toBeGreaterThanOrEqual(3.0);
      expect(focusRingOnSurface).toBeGreaterThanOrEqual(3.0);
    });

    it('verifies WCAG 2.2 AA contrast in Dark Mode (min 4.5:1 text, 3:1 non-text/borders)', () => {
      // Dark Mode Tokens:
      // --bg-surface: #0f172a (Slate 900)
      // --bg-page: #020617 (Slate 950)
      // --fg-default: #f8fafc (Slate 50)
      // --color-primary: #3b82f6 (Brand 500)
      // --focus-ring: #ffffff

      const textOnSurface = calculateWcagContrast('#f8fafc', '#0f172a');
      const textOnPage = calculateWcagContrast('#f8fafc', '#020617');
      const primaryOnSurface = calculateWcagContrast('#3b82f6', '#0f172a');
      const primaryButtonFg = calculateWcagContrast('#ffffff', '#3b82f6');
      const focusRingOnSurface = calculateWcagContrast('#ffffff', '#0f172a');

      // Normal text requires >= 4.5:1 (WCAG AA)
      expect(textOnSurface).toBeGreaterThanOrEqual(4.5);
      expect(textOnPage).toBeGreaterThanOrEqual(4.5);

      // Non-text graphical UI and focus rings require >= 3.0:1
      expect(primaryOnSurface).toBeGreaterThanOrEqual(3.0);
      expect(primaryButtonFg).toBeGreaterThanOrEqual(3.0);
      expect(focusRingOnSurface).toBeGreaterThanOrEqual(3.0);
    });

    it('verifies High Contrast Mode contrast exceeds WCAG AAA (>= 7:1 text, >= 3:1 non-text)', () => {
      // High Contrast Light
      const hcLightText = calculateWcagContrast('#000000', '#ffffff');
      const hcLightBorder = calculateWcagContrast('#000000', '#ffffff');
      const hcLightPrimary = calculateWcagContrast('#1d4ed8', '#ffffff');
      const hcLightFocus = calculateWcagContrast('#000000', '#ffffff');

      expect(hcLightText).toBeGreaterThanOrEqual(7.0);
      expect(hcLightBorder).toBeGreaterThanOrEqual(3.0);
      expect(hcLightPrimary).toBeGreaterThanOrEqual(4.5);
      expect(hcLightFocus).toBeGreaterThanOrEqual(3.0);

      // High Contrast Dark
      const hcDarkText = calculateWcagContrast('#ffffff', '#000000');
      const hcDarkBorder = calculateWcagContrast('#ffffff', '#000000');
      const hcDarkPrimary = calculateWcagContrast('#60a5fa', '#000000');
      const hcDarkFocus = calculateWcagContrast('#ffffff', '#000000');

      expect(hcDarkText).toBeGreaterThanOrEqual(7.0);
      expect(hcDarkBorder).toBeGreaterThanOrEqual(3.0);
      expect(hcDarkPrimary).toBeGreaterThanOrEqual(4.5);
      expect(hcDarkFocus).toBeGreaterThanOrEqual(3.0);
    });

    it('verifies compound overlay contrast (modal scrim, toast surfaces, popover cards)', () => {
      // Scrim background (rgba(0,0,0,0.4) over light page -> ~#64748b; rgba(0,0,0,0.7) over dark -> ~#000000)
      // Elevated card surface on dark page: Slate 900 (#0f172a) on Slate 950 (#020617)
      const elevatedDarkCardContrast = calculateWcagContrast('#0f172a', '#020617');
      expect(elevatedDarkCardContrast).toBeGreaterThanOrEqual(1.1);

      // Toast feedback borders:
      // Success border (Green 500 #10b981) vs White: 1.83:1
      // Danger border (Red 500 #ef4444) vs White: 3.48:1
      const dangerBorderLight = calculateWcagContrast('#ef4444', '#ffffff');
      expect(dangerBorderLight).toBeGreaterThanOrEqual(3.0);
    });
  });

  /* ==========================================================================
     3. RTL / DIRECTIONALITY VISUAL BEHAVIOR
     ========================================================================== */

  describe('3. RTL / Directionality Visual Behavior', () => {
    it('uses CSS logical properties (padding-inline, margin-inline) in compiled styles', () => {
      // Verify compiled stylesheet contains logical properties for bidirectional layout
      expect(stylesCss).toContain('padding-inline:');
      expect(stylesCss).toContain('margin-inline-start:');
      expect(stylesCss).toContain('margin-inline-end:');
    });

    it('dynamically adapts layout containers when dir="rtl" is applied', () => {
      const container = document.createElement('div');
      container.className = 'flex items-center gap-2';
      container.setAttribute('dir', 'rtl');

      const child1 = document.createElement('span');
      child1.textContent = 'First';
      const child2 = document.createElement('span');
      child2.textContent = 'Second';

      container.appendChild(child1);
      container.appendChild(child2);
      document.body.appendChild(container);

      // Verify DOM structure and attributes
      expect(container.getAttribute('dir')).toBe('rtl');
      expect(container.firstElementChild?.textContent).toBe('First');
      expect(container.lastElementChild?.textContent).toBe('Second');

      document.body.removeChild(container);
    });

    it('verifies Locale RTL detection helper produces correct direction tags', () => {
      // Standard RTL language codes: ar (Arabic), he (Hebrew), fa (Persian), ur (Urdu)
      const RTL_CODES = ['ar', 'ar-EG', 'ar-SA', 'he', 'he-IL', 'fa', 'ur'];
      const LTR_CODES = ['en', 'en-US', 'fr', 'de', 'es', 'ja', 'zh'];

      // Inline parity check with @nofinite/locale getDirection logic
      const isRtl = (tag: string) => {
        const base = tag.toLowerCase().split(/[-_]/)[0];
        return ['ar', 'he', 'fa', 'ur', 'ps', 'sd', 'ug', 'yi'].includes(base);
      };

      for (const code of RTL_CODES) {
        expect(isRtl(code), `Expected ${code} to be RTL`).toBe(true);
      }

      for (const code of LTR_CODES) {
        expect(isRtl(code), `Expected ${code} to be LTR`).toBe(false);
      }
    });

    it('ensures bidirectional navigation icons preserve geometry when dir="rtl"', () => {
      // When dir="rtl", navigational icons (chevrons, arrows) should flip or maintain square dimensions
      const chevron = document.createElement('svg');
      chevron.setAttribute('width', '16');
      chevron.setAttribute('height', '16');
      chevron.setAttribute('viewBox', '0 0 24 24');
      chevron.className = 'w-4 h-4 rtl-flip';

      expect(chevron.getAttribute('width')).toBe('16');
      expect(chevron.getAttribute('height')).toBe('16');
    });
  });

  /* ==========================================================================
     4. ZERO DUPLICATE CSS DEFINITIONS & SHORTCUT PURITY
     ========================================================================== */

  describe('4. Zero Duplicate CSS Definitions & Shortcut Purity', () => {
    const SHORTCUT_FILES = [
      'primitives.ts',
      'forms.ts',
      'overlays.ts',
      'widgets.ts',
      'media.ts',
    ];

    it('confirms zero duplicate shortcut keys defined across all NUICSS shortcut files', () => {
      const allShortcuts = new Map<string, string[]>();

      for (const filename of SHORTCUT_FILES) {
        const filePath = path.join(NUICSS_SRC_DIR, 'shortcuts', filename);
        const content = fs.readFileSync(filePath, 'utf-8');

        // Extract `['shortcut-name', '...']` tuples
        const regex = /\[\s*['"`]([a-zA-Z0-9_\-\[\]:]+)['"`]\s*,\s*['"`]([^'"`]+)['"`]\s*\]/g;
        let match;
        while ((match = regex.exec(content)) !== null) {
          const key = match[1];
          const existing = allShortcuts.get(key) || [];
          existing.push(filename);
          allShortcuts.set(key, existing);
        }
      }

      const duplicates = Array.from(allShortcuts.entries()).filter(
        ([_, files]) => files.length > 1
      );

      expect(
        duplicates,
        `Found duplicate shortcut keys across shortcut files: ${JSON.stringify(duplicates)}`
      ).toHaveLength(0);
    });

    it('ensures zero orphaned fallback color tokens in semantic surface definitions', () => {
      // Semantic surfaces should reference primitive tokens (slate, white, brand)
      // rather than hardcoded raw RGB/hex color literals
      expect(themeCss).not.toMatch(/--bg-surface:\s*#[0-9a-fA-F]{3,6}/);
      expect(themeCss).toContain('--bg-surface: var(--white);');
      expect(themeCss).toMatch(/--bg-page:\s*var\(--(color-neutral-50|slate-50)\);/);
    });

    it('verifies OKLCH color spaces are configured for modern perceptual uniformity', () => {
      expect(themeCss).toContain('oklch(');
      expect(themeCss).toContain('color-mix(in oklch');
    });

    it('confirms zero colliding property rules between component shortcuts and reset base', () => {
      // Verify that component classes like .btn, .card, .input, .modal do not use !important
      // in their base shortcut definitions
      const primitivesPath = path.join(NUICSS_SRC_DIR, 'shortcuts/primitives.ts');
      const formsPath = path.join(NUICSS_SRC_DIR, 'shortcuts/forms.ts');
      const primitivesContent = fs.readFileSync(primitivesPath, 'utf-8');
      const formsContent = fs.readFileSync(formsPath, 'utf-8');

      expect(primitivesContent).not.toContain('!important');
      expect(formsContent).not.toContain('!important');
    });
  });
});
